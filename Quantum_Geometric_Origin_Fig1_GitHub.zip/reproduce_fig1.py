"""
Reproduce Fig. 1 and Fig. S1 for:
Quantum Geometric Origin of Non-Adiabatic Instability in Driven Bosonic Systems

Run:
    python reproduce_fig1.py

Dependencies:
    numpy, pandas, scipy, matplotlib
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.linalg import eigh

HERE = Path(__file__).resolve().parent
(HERE / "figures").mkdir(exist_ok=True)
(HERE / "data").mkdir(exist_ok=True)

ETA = 0.5
TIMES = np.linspace(0.5, 5.0, 20)
XI = np.logspace(-2, 3, 300)

def propagate(H, psi0, times):
    eigenvalues, eigenvectors = eigh(H, check_finite=False)
    coefficients = eigenvectors.conj().T @ psi0
    return eigenvectors @ (
        coefficients[:, None] * np.exp(-1j*np.outer(eigenvalues, times))
    )

def two_level():
    values = []
    for xi in XI:
        U = ETA/xi
        H = np.array([[0.0, ETA], [ETA, U]], float)
        psi = propagate(H, np.array([1.0, 0.0], complex), TIMES)
        values.append(np.mean(np.abs(psi[1])**2))
    return np.asarray(values)

def three_level():
    values = []
    for xi in XI:
        U = ETA/xi
        H = np.array([[0.0, ETA, 0.0],
                      [ETA, 0.0, ETA/np.sqrt(2)],
                      [0.0, ETA/np.sqrt(2), U]], float)
        psi = propagate(H, np.array([1.0, 0.0, 0.0], complex), TIMES)
        p1, p2 = np.abs(psi[1])**2, np.abs(psi[2])**2
        denom = p1+p2
        leakage = np.divide(p2, denom, out=np.zeros_like(denom), where=denom>0)
        values.append(np.mean(leakage))
    return np.asarray(values)

def fock(N):
    n = np.arange(0, N, 2)
    G = ETA/4
    values = []
    for xi in XI:
        U = ETA/xi
        H = np.diag(U*n*(n-1)).astype(float)
        for j, nj in enumerate(n[:-1]):
            coupling = G*np.sqrt((nj+1)*(nj+2))
            H[j,j+1] = H[j+1,j] = coupling
        psi0 = np.zeros(len(n), complex)
        psi0[0] = 1
        psi = propagate(H, psi0, TIMES)
        probability = np.abs(psi)**2
        values.append(np.mean((n[:,None]*probability).sum(axis=0)))
    return np.asarray(values)

two = two_level()
three = three_level()
fock_results = {N:fock(N) for N in (50,100,200,400)}
norm = lambda x: x/np.max(x)

pd.DataFrame({
    "xi":XI,
    "two_level_probability":two,
    "three_level_leakage_fraction":three,
    **{f"fock_N{N}_mean_occupation":v for N,v in fock_results.items()}
}).to_csv(HERE/"data"/"fig1_data.csv", index=False)

fig = plt.figure(figsize=(8.4,5.2))
plt.plot(XI,norm(two),"--",lw=1.9,label="Two-level excitation")
plt.plot(XI,norm(three),"-.",lw=1.9,label="Three-level leakage")
plt.plot(XI,norm(fock_results[400]),"-",lw=2.2,
         label=r"Many-level $\langle\hat n\rangle$ ($N=400$)")
plt.axvspan(.20,.32,alpha=.12)
plt.axvline(.25,ls=":",lw=1.4,label=r"Expansion bound $\xi_0=1/4$")
plt.axvspan(13,16,alpha=.16,label=r"Activation range $\xi\simeq13$--$16$")
plt.xscale("log"); plt.yscale("log")
plt.xlim(1e-2,1e3); plt.ylim(1e-4,1.05)
plt.xlabel(r"Crossover parameter $\xi=\eta/U$")
plt.ylabel("Individually normalized response")
plt.legend(frameon=False,fontsize=8.7,loc="center left",bbox_to_anchor=(1.02,.5))
plt.tick_params(direction="in",which="both",top=True,right=True)
plt.tight_layout()
fig.savefig(HERE/"figures"/"Fig1_Q1.pdf",bbox_inches="tight")
fig.savefig(HERE/"figures"/"Fig1_Q1.png",dpi=600,bbox_inches="tight")
