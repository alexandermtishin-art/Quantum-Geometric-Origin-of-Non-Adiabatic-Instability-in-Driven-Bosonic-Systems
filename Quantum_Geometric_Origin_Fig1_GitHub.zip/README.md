# Figure 1 reproducibility package

Repository target:
`Quantum-Geometric-Origin-of-Non-Adiabatic-Instability-in-Driven-Bosonic-Systems`

## Reproduce

```bash
python -m pip install -r requirements.txt
python reproduce_fig1.py
```

## Contents

- `reproduce_fig1.py`: standalone calculation and plotting script.
- `notebooks/Geometry_original.ipynb`: supplied original Colab notebook.
- `figures/Fig1_Q1.pdf`: vector main figure without caption.
- `figures/Fig1_Q1.png`: 600 dpi raster version.
- `figures/FigS1_convergence.*`: explicit N=50,100,200,400 convergence check.
- `data/fig1_data.csv`: numerical values plotted.
- `validation/validation_report.json`: independent numerical checks.

## Model and protocol

The package follows the supplied notebook:
- fixed drive parameter `eta = 0.5`;
- `xi = eta/U`;
- time average on `t = 0.5 ... 5.0`;
- two-level excitation probability;
- three-level leakage fraction;
- Kerr pair-driven many-level Hamiltonian;
- vacuum initial state.

The main figure extends the scan to `xi = 10^3` and uses `N=400`.
The three curves are normalized separately and represent different observables.
Their comparison is therefore qualitative, not a pointwise equality.

## Independent numerical check

Maximum absolute discrepancy between the notebook's direct matrix-exponential
calculation and an independent eigendecomposition calculation on the original
two-level grid:

`5.551e-16`

This is at machine precision.
